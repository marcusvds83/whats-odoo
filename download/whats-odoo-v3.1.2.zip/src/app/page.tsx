'use client'

import { useState, useMemo, useCallback } from 'react'
import { useWhatsApp } from '@/lib/use-whatsapp'
import { useOdoo } from '@/lib/use-odoo'
import { QRCodePanel } from '@/components/whatsapp/QRCodePanel'
import { ConversationList } from '@/components/whatsapp/ConversationList'
import { ChatView } from '@/components/whatsapp/ChatView'
import { OdooConfigForm } from '@/components/odoo/OdooConfigForm'
import { OdooLinkPanel } from '@/components/odoo/OdooLinkPanel'
import { AutoSyncSettingsPanel } from '@/components/odoo/AutoSyncSettings'

import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'
import {
  MessageCircle,
  Settings,
  LayoutDashboard,
  Smartphone,
  Link2,
  Wifi,
  WifiOff,
  Server,
  Users,
  TrendingUp,
  ShoppingCart,
  ClipboardList,
  PanelRightOpen,
  PanelRightClose,
  Zap,
} from 'lucide-react'

type Tab = 'dashboard' | 'whatsapp' | 'conversations' | 'settings'

function DashboardView({
  waStatus,
  waMe,
  waConversations,
  odooStatus,
  onNavigate,
}: {
  waStatus: { connected: boolean; reason?: string }
  waMe: { id: string; name?: string; profilePicUrl?: string } | null
  waConversations: Array<{ jid: string; unreadCount: number }>
  odooStatus: { connected: boolean; url?: string; db?: string; username?: string }
  onNavigate: (tab: Tab) => void
}) {
  const totalUnread = waConversations.reduce((s, c) => s + c.unreadCount, 0)

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Visao geral da integracao WhatsApp e Odoo
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="relative overflow-hidden">
          <div className={cn("absolute top-0 left-0 w-1 h-full", waStatus.connected ? "bg-emerald-500" : "bg-red-400")} />
          <CardHeader className="pb-2 pl-5">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-muted-foreground">WhatsApp</CardTitle>
              {waStatus.connected ? <Wifi className="size-4 text-emerald-500" /> : <WifiOff className="size-4 text-red-400" />}
            </div>
          </CardHeader>
          <CardContent className="pl-5">
            <div className="text-2xl font-bold">{waStatus.connected ? 'Conectado' : 'Desconectado'}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {waStatus.connected ? (waMe?.name || waMe?.id?.split('@')[0] || 'Sessao ativa') : 'Escaneie o QR Code para conectar'}
            </p>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <div className={cn("absolute top-0 left-0 w-1 h-full", odooStatus.connected ? "bg-emerald-500" : "bg-amber-400")} />
          <CardHeader className="pb-2 pl-5">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-muted-foreground">Odoo</CardTitle>
              <Server className={cn("size-4", odooStatus.connected ? "text-emerald-500" : "text-amber-400")} />
            </div>
          </CardHeader>
          <CardContent className="pl-5">
            <div className="text-2xl font-bold">{odooStatus.connected ? 'Conectado' : 'Desconectado'}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {odooStatus.connected ? odooStatus.url : 'Configure as credenciais do Odoo'}
            </p>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
          <CardHeader className="pb-2 pl-5">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-muted-foreground">Conversas</CardTitle>
              <MessageCircle className="size-4 text-primary" />
            </div>
          </CardHeader>
          <CardContent className="pl-5">
            <div className="text-2xl font-bold">{waConversations.length}</div>
            <p className="text-xs text-muted-foreground mt-1">{totalUnread} nao lidas</p>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <div className={cn("absolute top-0 left-0 w-1 h-full", waStatus.connected && odooStatus.connected ? "bg-emerald-500" : "bg-muted")} />
          <CardHeader className="pb-2 pl-5">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-muted-foreground">Integracao</CardTitle>
              <Link2 className="size-4 text-muted-foreground" />
            </div>
          </CardHeader>
          <CardContent className="pl-5">
            <div className="text-2xl font-bold">{waStatus.connected && odooStatus.connected ? 'Ativa' : 'Inativa'}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {waStatus.connected && odooStatus.connected ? 'WhatsApp e Odoo conectados' : 'Conecte ambos para ativar'}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Acoes Rapidas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {!waStatus.connected && (
              <Button variant="outline" className="justify-start gap-2 h-auto py-3" onClick={() => onNavigate('whatsapp')}>
                <Smartphone className="size-4 text-emerald-500" />
                <div className="text-left">
                  <div className="text-sm font-medium">Conectar WhatsApp</div>
                  <div className="text-xs text-muted-foreground">Escanear QR Code</div>
                </div>
              </Button>
            )}
            {!odooStatus.connected && (
              <Button variant="outline" className="justify-start gap-2 h-auto py-3" onClick={() => onNavigate('settings')}>
                <Server className="size-4 text-amber-500" />
                <div className="text-left">
                  <div className="text-sm font-medium">Configurar Odoo</div>
                  <div className="text-xs text-muted-foreground">Conectar ao servidor</div>
                </div>
              </Button>
            )}
            {waStatus.connected && (
              <Button variant="outline" className="justify-start gap-2 h-auto py-3" onClick={() => onNavigate('conversations')}>
                <MessageCircle className="size-4 text-primary" />
                <div className="text-left">
                  <div className="text-sm font-medium">Ver Conversas</div>
                  <div className="text-xs text-muted-foreground">{waConversations.length} conversas ativas</div>
                </div>
              </Button>
            )}
            {waStatus.connected && odooStatus.connected && (
              <Button variant="outline" className="justify-start gap-2 h-auto py-3" onClick={() => onNavigate('conversations')}>
                <Zap className="size-4 text-yellow-500" />
                <div className="text-left">
                  <div className="text-sm font-medium">Criar Lead</div>
                  <div className="text-xs text-muted-foreground">A partir de conversa</div>
                </div>
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Como Funciona</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="flex gap-3">
              <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 text-sm font-bold">1</div>
              <div>
                <p className="text-sm font-medium">Conecte WhatsApp</p>
                <p className="text-xs text-muted-foreground mt-0.5">Escaneie o QR Code com o WhatsApp Business no celular para vincular sua conta</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 text-sm font-bold">2</div>
              <div>
                <p className="text-sm font-medium">Configure Odoo</p>
                <p className="text-xs text-muted-foreground mt-0.5">Insira as credenciais do seu Odoo SaaS (URL, banco, usuario e senha)</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary text-sm font-bold">3</div>
              <div>
                <p className="text-sm font-medium">Crie Leads e Contatos</p>
                <p className="text-xs text-muted-foreground mt-0.5">A partir de qualquer conversa WhatsApp, crie leads e contatos no Odoo com um clique</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function ConversationsView({
  conversations,
  selectedJid,
  selectedConversation,
  currentMessages,
  showOdooPanel,
  odooStatus,
  odooSyncInfo,
  onSelectConversation,
  onSendMessage,
  onMarkRead,
  onToggleOdooPanel,
  onCreateLeadFromChat,
  onCreateContactFromChat,
  onLinkConversation,
  onSearchContacts,
  onSearchLeads,
  onSearchSales,
  onSearchTasks,
  onOdooCreateLead,
  onOdooCreateContact,
  onOdooCreateTask,
  onLogMessage,
}: {
  conversations: any[]
  selectedJid: string | null
  selectedConversation: any
  currentMessages: any[]
  showOdooPanel: boolean
  odooStatus: { connected: boolean }
  odooSyncInfo: { partnerId: number | null; leadId: number | null } | null
  onSelectConversation: (jid: string) => void
  onSendMessage: (jid: string, text: string) => Promise<boolean>
  onMarkRead: (jid: string) => void
  onToggleOdooPanel: (show: boolean) => void
  onCreateLeadFromChat: (jid: string, data: { name: string; phone: string; pushName: string | null; messages: any[] }) => Promise<boolean>
  onCreateContactFromChat: (jid: string, data: { name: string; phone: string; pushName: string | null }) => Promise<boolean>
  onLinkConversation: any
  onSearchContacts: any
  onSearchLeads: any
  onSearchSales: any
  onSearchTasks: any
  onOdooCreateLead: any
  onOdooCreateContact: any
  onOdooCreateTask: any
  onLogMessage: any
}) {
  return (
    <div className="flex h-full">
      <div className={cn(
        "border-r bg-background transition-all duration-200",
        selectedJid ? "w-80 lg:w-96" : "w-full max-w-lg mx-auto"
      )}>
        <ConversationList
          conversations={conversations}
          selectedJid={selectedJid}
          onSelect={onSelectConversation}
        />
      </div>

      {selectedJid && (
        <div className="flex-1 flex">
          <div className={cn("flex-1 transition-all duration-200", showOdooPanel && "hidden lg:block")}>
            <ChatView
              conversation={selectedConversation}
              messages={currentMessages}
              onSendMessage={onSendMessage}
              onMarkRead={onMarkRead}
              odooConnected={odooStatus.connected}
              odooSyncInfo={odooSyncInfo}
              onCreateLead={onCreateLeadFromChat}
              onCreateContact={onCreateContactFromChat}
              onToggleOdooPanel={onToggleOdooPanel}
              odooPanelOpen={showOdooPanel}
            />
          </div>

          {showOdooPanel && (
            <div className="w-80 lg:w-96 border-l bg-background flex flex-col">
              <div className="flex items-center justify-between px-3 py-2 border-b">
                <div className="flex items-center gap-2">
                  <Link2 className="size-4 text-primary" />
                  <span className="text-sm font-medium">Odoo</span>
                  {odooStatus.connected && (
                    <Badge variant="outline" className="text-[10px] bg-emerald-50 text-emerald-700 border-emerald-200">Conectado</Badge>
                  )}
                </div>
                <Button variant="ghost" size="icon" className="size-7" onClick={() => onToggleOdooPanel(false)}>
                  <PanelRightClose className="size-4" />
                </Button>
              </div>
              <OdooLinkPanel
                conversationJid={selectedJid}
                conversationPhone={selectedConversation?.phone || null}
                onLinkConversation={onLinkConversation}
                onSearchContacts={onSearchContacts}
                onSearchLeads={onSearchLeads}
                onSearchSales={onSearchSales}
                onSearchTasks={onSearchTasks}
                onCreateLead={onOdooCreateLead}
                onCreateContact={onOdooCreateContact}
                onCreateTask={onOdooCreateTask}
                onLogMessage={onLogMessage}
                odooConnected={odooStatus.connected}
              />
            </div>
          )}

          {!showOdooPanel && !odooStatus.connected && (
            <div className="border-l bg-muted/30 flex flex-col items-center pt-3 px-1">
              <Button variant="ghost" size="icon" className="size-8" onClick={() => onToggleOdooPanel(true)} title="Abrir painel Odoo">
                <PanelRightOpen className="size-4" />
              </Button>
              <Separator className="my-2 w-4" />
              <div className="flex flex-col gap-1 py-2">
                <div className="flex size-7 items-center justify-center"><Users className="size-3.5 text-muted-foreground" /></div>
                <div className="flex size-7 items-center justify-center"><TrendingUp className="size-3.5 text-muted-foreground" /></div>
                <div className="flex size-7 items-center justify-center"><ShoppingCart className="size-3.5 text-muted-foreground" /></div>
                <div className="flex size-7 items-center justify-center"><ClipboardList className="size-3.5 text-muted-foreground" /></div>
              </div>
            </div>
          )}

          {/* Mini action bar when Odoo panel is closed but connected */}
          {!showOdooPanel && odooStatus.connected && (
            <div className="border-l bg-muted/30 flex flex-col items-center pt-3 px-1 gap-2">
              <Button variant="outline" size="icon" className="size-8 border-primary/30 text-primary" onClick={() => onToggleOdooPanel(true)} title="Vincular ao Chatter do Odoo">
                <Link2 className="size-4" />
              </Button>
              <Separator className="w-4" />
              <div className="flex flex-col gap-1">
                <div className="flex size-7 items-center justify-center rounded-md bg-emerald-50 text-emerald-600"><Users className="size-3.5" /></div>
                <div className="flex size-7 items-center justify-center rounded-md bg-amber-50 text-amber-600"><TrendingUp className="size-3.5" /></div>
                <div className="flex size-7 items-center justify-center rounded-md bg-sky-50 text-sky-600"><ShoppingCart className="size-3.5" /></div>
                <div className="flex size-7 items-center justify-center rounded-md bg-violet-50 text-violet-600"><ClipboardList className="size-3.5" /></div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function NavItem({ icon, label, active, onClick, badge }: {
  icon: React.ReactNode
  label: string
  active: boolean
  onClick: () => void
  badge?: string
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'w-full flex items-center gap-3 px-2 py-2 rounded-lg text-sm transition-colors',
        'hover:bg-muted/80 focus-visible:outline-none focus-visible:bg-muted/80',
        active ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground',
      )}
    >
      <span className="shrink-0">{icon}</span>
      <span className="hidden lg:block flex-1 text-left truncate">{label}</span>
      {badge && (
        <Badge className="size-5 p-0 flex items-center justify-center text-[10px] bg-emerald-500 text-white border-0">
          {badge === 'online' ? '\u25CF' : badge}
        </Badge>
      )}
    </button>
  )
}

function StatusIndicator({ label, connected }: { label: string; connected: boolean }) {
  return (
    <div className="flex items-center gap-2 px-2 py-1.5 text-xs">
      <span className={cn('size-2 rounded-full shrink-0', connected ? 'bg-emerald-500' : 'bg-muted-foreground/30')} />
      <span className="hidden lg:block text-muted-foreground truncate">{label}</span>
      <span className="hidden lg:block ml-auto font-medium text-[10px]">{connected ? 'ON' : 'OFF'}</span>
    </div>
  )
}

// Helper to format conversation for Odoo description
function formatConversationForDescription(
  pushName: string | null,
  phone: string | null,
  messages: Array<{ fromMe: boolean; textContent: string | null; mediaType: string | null; timestamp: string }>
): string {
  const lines: string[] = []
  lines.push(`Conversa WhatsApp com ${pushName || phone || 'Contato'}`)
  lines.push(`Telefone: ${phone || 'N/A'}`)
  lines.push(`Data de criacao do lead: ${new Date().toLocaleString('pt-BR')}`)
  lines.push('')
  lines.push('--- Historico da Conversa ---')
  lines.push('')

  for (const msg of messages) {
    const time = new Date(msg.timestamp).toLocaleString('pt-BR')
    const sender = msg.fromMe ? 'Voce' : (pushName || phone || 'Contato')
    const content = msg.textContent || `[${msg.mediaType || 'Midia'}]`
    lines.push(`[${time}] ${sender}: ${content}`)
  }

  return lines.join('\n')
}

export default function HomePage() {
  const wa = useWhatsApp()
  const odoo = useOdoo()

  const [activeTab, setActiveTab] = useState<Tab>('dashboard')
  const [selectedJid, setSelectedJid] = useState<string | null>(null)
  const [showOdooPanel, setShowOdooPanel] = useState(false)

  const selectedConversation = useMemo(() => {
    if (!selectedJid) return null
    return wa.conversations.find(c => c.jid === selectedJid) || null
  }, [selectedJid, wa.conversations])

  // Get Odoo sync info for the selected conversation
  const odooSyncInfo = useMemo(() => {
    if (!selectedJid) return null
    const sync = wa.odooSyncMap.get(selectedJid)
    return sync ? { partnerId: sync.partnerId, leadId: sync.leadId } : null
  }, [selectedJid, wa.odooSyncMap])

  const handleSelectConversation = (jid: string) => {
    setSelectedJid(jid)
    wa.loadMessages(jid)
    wa.markRead(jid)
    setActiveTab('conversations')
  }

  // ========== Create Lead from Conversation (ChatView action buttons) ==========
  const handleCreateLeadFromChat = useCallback(async (
    jid: string,
    data: { name: string; phone: string; pushName: string | null; messages: any[] }
  ): Promise<boolean> => {
    try {
      // Step 1: Search or create contact in Odoo
      const contactResult = await odoo.searchOrCreateContact({
        phone: data.phone,
        name: data.pushName || data.phone,
      })

      if (!contactResult.success || !contactResult.id) {
        toast.error('Erro ao criar contato no Odoo', { description: contactResult.error })
        return false
      }

      // Step 2: Create lead with conversation as description
      const description = data.messages.length > 0
        ? formatConversationForDescription(data.pushName, data.phone, data.messages)
        : `Conversa iniciada via WhatsApp em ${new Date().toLocaleString('pt-BR')}`

      const leadResult = await odoo.createLead({
        name: data.name,
        phone: data.phone,
        partner_id: contactResult.id,
        description,
        type: 'lead',
        whatsapp_number: data.phone,
      })

      if (!leadResult.success || !leadResult.id) {
        toast.error('Erro ao criar lead no Odoo', { description: leadResult.error })
        return false
      }

      // Step 3: Link conversation to the lead
      await odoo.linkConversation({
        jid,
        model: 'crm.lead',
        recordId: leadResult.id,
        phone: data.phone,
      })

      // Step 4: Also link to the contact
      await odoo.linkConversation({
        jid,
        model: 'res.partner',
        recordId: contactResult.id,
        phone: data.phone,
      })

      // Update Odoo sync map
      wa.odooSyncMap.set(jid, {
        jid,
        phone: data.phone,
        partnerId: contactResult.id,
        leadId: leadResult.id,
        mailMessageId: null,
        activityId: null,
        created: { partner: contactResult.created || false, lead: true },
        errors: [],
      })

      toast.success('Lead criado com sucesso!', {
        description: `Lead #${leadResult.id} criado para ${data.pushName || data.phone}`,
      })

      return true
    } catch (error: any) {
      toast.error('Erro ao criar lead', { description: error.message })
      return false
    }
  }, [odoo, wa.odooSyncMap])

  // ========== Create Contact from Conversation (ChatView action buttons) ==========
  const handleCreateContactFromChat = useCallback(async (
    jid: string,
    data: { name: string; phone: string; pushName: string | null }
  ): Promise<boolean> => {
    try {
      const contactResult = await odoo.createContact({
        name: data.name,
        phone: data.phone,
        mobile: data.phone,
        whatsapp: data.phone,
      })

      if (!contactResult.success || !contactResult.id) {
        toast.error('Erro ao criar contato no Odoo', { description: contactResult.error })
        return false
      }

      // Link conversation to the contact
      await odoo.linkConversation({
        jid,
        model: 'res.partner',
        recordId: contactResult.id,
        phone: data.phone,
      })

      // Update Odoo sync map
      const existing = wa.odooSyncMap.get(jid)
      wa.odooSyncMap.set(jid, {
        jid,
        phone: data.phone,
        partnerId: contactResult.id,
        leadId: existing?.leadId || null,
        mailMessageId: null,
        activityId: null,
        created: { partner: true, lead: false },
        errors: [],
      })

      toast.success('Contato criado com sucesso!', {
        description: `Contato #${contactResult.id} criado para ${data.name}`,
      })

      return true
    } catch (error: any) {
      toast.error('Erro ao criar contato', { description: error.message })
      return false
    }
  }, [odoo, wa.odooSyncMap])

  return (
    <div className="flex h-screen">
      <nav className="w-14 lg:w-56 border-r bg-muted/30 flex flex-col shrink-0">
        <div className="h-14 flex items-center px-3 lg:px-4 border-b">
          <div className="flex items-center gap-2">
            <div className="flex size-8 items-center justify-center rounded-lg bg-emerald-600 text-white">
              <MessageCircle className="size-4" />
            </div>
            <div className="hidden lg:block">
              <p className="text-sm font-bold leading-tight">WA-Odoo</p>
              <p className="text-[10px] text-muted-foreground">Middleware v3.1.2</p>
            </div>
          </div>
        </div>

        <div className="flex-1 py-2 space-y-1 px-2">
          <NavItem icon={<LayoutDashboard className="size-4" />} label="Dashboard" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
          <NavItem icon={<Smartphone className="size-4" />} label="WhatsApp" active={activeTab === 'whatsapp'} onClick={() => setActiveTab('whatsapp')} badge={wa.status.connected ? 'online' : undefined} />
          <NavItem
            icon={<MessageCircle className="size-4" />} label="Conversas" active={activeTab === 'conversations'} onClick={() => setActiveTab('conversations')}
            badge={wa.conversations.reduce((s, c) => s + c.unreadCount, 0) > 0 ? String(wa.conversations.reduce((s, c) => s + c.unreadCount, 0)) : undefined}
          />
          <NavItem icon={<Settings className="size-4" />} label="Configuracoes" active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} />
        </div>

        <div className="p-2 border-t space-y-1">
          <StatusIndicator label="WhatsApp" connected={wa.status.connected} />
          <StatusIndicator label="Odoo" connected={odoo.status.connected} />
        </div>
      </nav>

      <main className="flex-1 overflow-hidden">
        {activeTab === 'dashboard' && (
          <DashboardView
            waStatus={wa.status}
            waMe={wa.me}
            waConversations={wa.conversations}
            odooStatus={odoo.status}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'whatsapp' && (
          <div className="p-6 flex items-start justify-center min-h-full">
            <QRCodePanel
              qrCode={wa.qrCode}
              status={wa.status}
              me={wa.me}
              onRequestQR={wa.requestQR}
              onDisconnect={wa.disconnect}
              isConnected={wa.status.connected}
            />
          </div>
        )}

        {activeTab === 'conversations' && (
          <ConversationsView
            conversations={wa.conversations}
            selectedJid={selectedJid}
            selectedConversation={selectedConversation}
            currentMessages={wa.currentMessages}
            showOdooPanel={showOdooPanel}
            odooStatus={odoo.status}
            odooSyncInfo={odooSyncInfo}
            onSelectConversation={handleSelectConversation}
            onSendMessage={wa.sendMessage}
            onMarkRead={wa.markRead}
            onToggleOdooPanel={setShowOdooPanel}
            onCreateLeadFromChat={handleCreateLeadFromChat}
            onCreateContactFromChat={handleCreateContactFromChat}
            onLinkConversation={odoo.linkConversation}
            onSearchContacts={odoo.searchContacts}
            onSearchLeads={odoo.searchLeads}
            onSearchSales={odoo.searchSales}
            onSearchTasks={odoo.searchTasks}
            onOdooCreateLead={odoo.createLead}
            onOdooCreateContact={odoo.createContact}
            onOdooCreateTask={odoo.createTask}
            onLogMessage={odoo.logMessage}
          />
        )}

        {activeTab === 'settings' && (
          <div className="p-6 max-w-2xl mx-auto space-y-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Configuracoes</h1>
              <p className="text-muted-foreground text-sm mt-1">Configure as conexoes e a sincronizacao automatica do middleware</p>
            </div>
            <OdooConfigForm
              status={odoo.status}
              onAuthenticate={odoo.authenticate}
              onDisconnect={odoo.disconnect}
              isConnected={odoo.status.connected}
            />
            <AutoSyncSettingsPanel
              odooConnected={odoo.status.connected}
              settings={odoo.autoSyncSettings}
              onUpdateSettings={odoo.updateAutoSyncSettings}
            />
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Smartphone className="size-4 text-emerald-500" />
                  <CardTitle className="text-base">Status WhatsApp</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Conexao</span>
                  <Badge variant={wa.status.connected ? 'default' : 'outline'} className={wa.status.connected ? 'bg-emerald-100 text-emerald-800 border-emerald-200' : ''}>
                    {wa.status.connected ? 'Conectado' : 'Desconectado'}
                  </Badge>
                </div>
                {wa.me && (
                  <>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Numero</span>
                      <span className="font-mono text-xs">{wa.me.id?.split('@')[0]}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Nome</span>
                      <span>{wa.me.name || 'N/A'}</span>
                    </div>
                  </>
                )}
                <Button variant={wa.status.connected ? 'destructive' : 'default'} className="w-full" onClick={() => setActiveTab('whatsapp')}>
                  {wa.status.connected ? 'Desconectar WhatsApp' : 'Conectar WhatsApp'}
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  )
}
