'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import {
  Send,
  Phone,
  User,
  ImageIcon,
  FileText,
  Video,
  Music,
  Paperclip,
  Check,
  CheckCheck,
  Clock,
  MessageSquare,
  ArrowDown,
  UserPlus,
  Target,
  Link2,
  Loader2,
  CheckCircle2,
  Search,
  TrendingUp,
  ShoppingCart,
  ClipboardList,
  X,
  Mail,
} from 'lucide-react'

interface ChatViewProps {
  conversation: {
    jid: string
    name: string | null
    phone: string | null
    pushName: string | null
    avatarUrl: string | null
  } | null
  messages: Array<{
    id: string
    whatsappId: string | null
    fromMe: boolean
    textContent: string | null
    mediaType: string | null
    timestamp: string
    status: string
  }>
  onSendMessage: (jid: string, text: string) => Promise<boolean>
  onMarkRead: (jid: string) => void
  // Odoo integration props
  odooConnected?: boolean
  odooSyncInfo?: {
    partnerId: number | null
    leadId: number | null
  } | null
  onCreateLead?: (jid: string, conversationData: { name: string; phone: string; pushName: string | null; messages: ChatViewProps['messages'] }) => Promise<boolean>
  onCreateContact?: (jid: string, conversationData: { name: string; phone: string; pushName: string | null }) => Promise<boolean>
  // Chatter dialog props
  onLinkConversation?: (data: { jid: string; model: string; recordId: number; phone?: string }) => Promise<{ success: boolean }>
  onSearchContacts?: (query?: string, limit?: number) => Promise<{ success: boolean; data?: any[] }>
  onSearchLeads?: (query?: string, limit?: number) => Promise<{ success: boolean; data?: any[] }>
  onSearchSales?: (query?: string, limit?: number) => Promise<{ success: boolean; data?: any[] }>
  onSearchTasks?: (query?: string, limit?: number) => Promise<{ success: boolean; data?: any[] }>
  onLogMessage?: (data: { model: string; recordId: number; message: string; fromWhatsApp?: boolean }) => Promise<{ success: boolean }>
  onToggleOdooPanel?: (show: boolean) => void
  odooPanelOpen?: boolean
}

function formatMessageTime(dateStr: string): string {
  const date = new Date(dateStr)
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

function formatMessageDate(dateStr: string): string {
  const date = new Date(dateStr)
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))

  if (diffDays === 0) return 'Hoje'
  if (diffDays === 1) return 'Ontem'
  return date.toLocaleDateString('pt-BR', { month: 'long', day: 'numeric', year: 'numeric' })
}

function getMediaIcon(mediaType: string | null) {
  switch (mediaType) {
    case 'image':
      return <ImageIcon className="size-4" />
    case 'video':
      return <Video className="size-4" />
    case 'audio':
    case 'ptt':
      return <Music className="size-4" />
    case 'document':
    case 'pdf':
      return <FileText className="size-4" />
    default:
      return <Paperclip className="size-4" />
  }
}

function getMediaLabel(mediaType: string | null): string {
  switch (mediaType) {
    case 'image':
      return 'Foto'
    case 'video':
      return 'Video'
    case 'audio':
      return 'Audio'
    case 'ptt':
      return 'Mensagem de voz'
    case 'document':
      return 'Documento'
    case 'pdf':
      return 'Documento PDF'
    case 'sticker':
      return 'Sticker'
    default:
      return 'Midia'
  }
}

function getMessageStatusIcon(status: string, fromMe: boolean) {
  if (!fromMe) return null

  switch (status) {
    case 'pending':
      return <Clock className="size-3.5 text-muted-foreground" />
    case 'sent':
      return <Check className="size-3.5 text-muted-foreground" />
    case 'delivered':
      return <CheckCheck className="size-3.5 text-muted-foreground" />
    case 'read':
      return <CheckCheck className="size-3.5 text-blue-500" />
    default:
      return <Clock className="size-3.5 text-muted-foreground" />
  }
}

function shouldShowDateDivider(
  currentMsg: { timestamp: string },
  prevMsg: { timestamp: string } | undefined
): boolean {
  if (!prevMsg) return true
  const currentDate = new Date(currentMsg.timestamp).toDateString()
  const prevDate = new Date(prevMsg.timestamp).toDateString()
  return currentDate !== prevDate
}

// Format conversation messages as text for Odoo lead description
function formatConversationForDescription(
  pushName: string | null,
  phone: string | null,
  messages: ChatViewProps['messages']
): string {
  const lines: string[] = []
  lines.push(`Conversa WhatsApp com ${pushName || phone || 'Contato'}`)
  lines.push(`Telefone: ${phone || 'N/A'}`)
  lines.push(`Data de criacao do lead: ${new Date().toLocaleString('pt-BR')}`)
  lines.push('')
  lines.push('--- Historico da Conversa ---')
  lines.push('')

  for (const msg of messages) {
    const time = new Date(msg.timestamp).toLocaleString('pt-BR')
    const sender = msg.fromMe ? 'Voce' : (pushName || phone || 'Contato')
    const content = msg.textContent || `[${getMediaLabel(msg.mediaType)}]`
    lines.push(`[${time}] ${sender}: ${content}`)
  }

  return lines.join('\n')
}

// ========== Chatter Link Dialog ==========

type ChatterModelKey = 'contacts' | 'leads' | 'sales' | 'tasks'

const CHATTER_MODELS: Record<ChatterModelKey, { model: string; label: string; icon: React.ElementType; placeholder: string }> = {
  contacts: { model: 'res.partner', label: 'Contato', icon: User, placeholder: 'Buscar contato por nome, telefone...' },
  leads: { model: 'crm.lead', label: 'Lead / Oportunidade', icon: TrendingUp, placeholder: 'Buscar lead por nome, empresa...' },
  sales: { model: 'sale.order', label: 'Venda', icon: ShoppingCart, placeholder: 'Buscar venda por nome, cliente...' },
  tasks: { model: 'project.task', label: 'Tarefa / Projeto', icon: ClipboardList, placeholder: 'Buscar tarefa por nome...' },
}

interface LinkedChatterRecord {
  model: string
  modelKey: ChatterModelKey
  recordId: number
  record: any
}

function ChatterLinkDialog({
  open,
  onOpenChange,
  conversationJid,
  conversationPhone,
  conversationPushName,
  messages,
  odooConnected,
  onLinkConversation,
  onSearchContacts,
  onSearchLeads,
  onSearchSales,
  onSearchTasks,
  onLogMessage,
  existingPartnerId,
  existingLeadId,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  conversationJid: string
  conversationPhone: string | null
  conversationPushName: string | null
  messages: ChatViewProps['messages']
  odooConnected: boolean
  onLinkConversation: (data: { jid: string; model: string; recordId: number; phone?: string }) => Promise<{ success: boolean }>
  onSearchContacts?: (query?: string, limit?: number) => Promise<{ success: boolean; data?: any[] }>
  onSearchLeads?: (query?: string, limit?: number) => Promise<{ success: boolean; data?: any[] }>
  onSearchSales?: (query?: string, limit?: number) => Promise<{ success: boolean; data?: any[] }>
  onSearchTasks?: (query?: string, limit?: number) => Promise<{ success: boolean; data?: any[] }>
  onLogMessage?: (data: { model: string; recordId: number; message: string; fromWhatsApp?: boolean }) => Promise<{ success: boolean }>
  existingPartnerId: number | null
  existingLeadId: number | null
}) {
  const [activeTab, setActiveTab] = useState<ChatterModelKey>('contacts')
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [searchLoading, setSearchLoading] = useState(false)
  const [searchSearched, setSearchSearched] = useState(false)
  const [linkedRecords, setLinkedRecords] = useState<LinkedChatterRecord[]>([])
  const [linkingId, setLinkingId] = useState<number | null>(null)
  const [postingMsg, setPostingMsg] = useState(false)
  const [chatterMessage, setChatterMessage] = useState('')
  const [selectedForChatter, setSelectedForChatter] = useState<LinkedChatterRecord | null>(null)

  // Pre-populate linked records from existing sync info
  useEffect(() => {
    if (open) {
      const existing: LinkedChatterRecord[] = []
      if (existingPartnerId) {
        existing.push({ model: 'res.partner', modelKey: 'contacts', recordId: existingPartnerId, record: { id: existingPartnerId, name: `Contato #${existingPartnerId}` } })
      }
      if (existingLeadId) {
        existing.push({ model: 'crm.lead', modelKey: 'leads', recordId: existingLeadId, record: { id: existingLeadId, name: `Lead #${existingLeadId}` } })
      }
      setLinkedRecords(existing)
      setSearchQuery('')
      setSearchResults([])
      setSearchSearched(false)
      setChatterMessage('')
      setSelectedForChatter(null)
    }
  }, [open, existingPartnerId, existingLeadId])

  const performSearch = useCallback(async (tab: ChatterModelKey, query: string) => {
    setSearchLoading(true)
    setSearchSearched(true)
    try {
      let result: { success: boolean; data?: any[] }
      const trimmed = query.trim() || undefined
      switch (tab) {
        case 'contacts':
          result = await (onSearchContacts?.(trimmed, 20) ?? { success: false })
          break
        case 'leads':
          result = await (onSearchLeads?.(trimmed, 20) ?? { success: false })
          break
        case 'sales':
          result = await (onSearchSales?.(trimmed, 20) ?? { success: false })
          break
        case 'tasks':
          result = await (onSearchTasks?.(trimmed, 20) ?? { success: false })
          break
        default:
          result = { success: false }
      }
      setSearchResults(result.success && result.data ? result.data : [])
    } catch {
      setSearchResults([])
    } finally {
      setSearchLoading(false)
    }
  }, [onSearchContacts, onSearchLeads, onSearchSales, onSearchTasks])

  // Debounced search
  const searchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const handleSearchChange = useCallback((value: string) => {
    setSearchQuery(value)
    if (searchTimerRef.current) clearTimeout(searchTimerRef.current)
    searchTimerRef.current = setTimeout(() => {
      if (odooConnected) performSearch(activeTab, value)
    }, 400)
  }, [activeTab, odooConnected, performSearch])

  // Auto-search on tab switch
  useEffect(() => {
    if (open && odooConnected) {
      setSearchSearched(false)
      setSearchResults([])
      performSearch(activeTab, '')
    }
  }, [activeTab, open]) // eslint-disable-line react-hooks/exhaustive-deps

  const handleLink = useCallback(async (model: string, modelKey: ChatterModelKey, recordId: number, record: any) => {
    setLinkingId(recordId)
    try {
      const result = await onLinkConversation({
        jid: conversationJid,
        model,
        recordId,
        phone: conversationPhone ?? undefined,
      })
      if (result.success) {
        setLinkedRecords(prev => {
          const filtered = prev.filter(lr => lr.model !== model)
          return [...filtered, { model, modelKey, recordId, record }]
        })
      }
    } finally {
      setLinkingId(null)
    }
  }, [conversationJid, conversationPhone, onLinkConversation])

  const isRecordLinked = useCallback((model: string, recordId: number) => {
    return linkedRecords.some(lr => lr.model === model && lr.recordId === recordId)
  }, [linkedRecords])

  const handlePostToChatter = useCallback(async () => {
    if (!selectedForChatter || !chatterMessage.trim()) return
    setPostingMsg(true)
    try {
      await onLogMessage?.({
        model: selectedForChatter.model,
        recordId: selectedForChatter.recordId,
        message: chatterMessage.trim(),
        fromWhatsApp: true,
      })
      setChatterMessage('')
      setSelectedForChatter(null)
    } finally {
      setPostingMsg(false)
    }
  }, [selectedForChatter, chatterMessage, onLogMessage])

  // Auto-generate a message from conversation history
  const autoFillConversationMsg = useCallback(() => {
    if (messages.length === 0) return
    const content = formatConversationForDescription(conversationPushName, conversationPhone, messages.slice(-20))
    setChatterMessage(content)
  }, [messages, conversationPushName, conversationPhone])

  const phone = conversationPhone || conversationJid.split('@')[0]

  // Get display name for a record
  const getRecordName = (record: any) => {
    return record.name || record.display_name || record.partner_name || `#${record.id}`
  }

  const getRecordSubInfo = (record: any, modelKey: ChatterModelKey) => {
    const parts: string[] = []
    if (record.phone) parts.push(record.phone)
    if (record.email || record.email_from) parts.push(record.email || record.email_from)
    if (modelKey === 'leads' && record.type) parts.push(record.type === 'lead' ? 'Lead' : 'Oportunidade')
    if (modelKey === 'sales' && record.state) parts.push(record.state)
    if (modelKey === 'tasks' && record.project_id) parts.push(record.project_id[1] || '')
    return parts.join(' · ')
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Link2 className="size-5 text-primary" />
            Vincular ao Chatter do Odoo
          </DialogTitle>
          <DialogDescription>
            Vincule esta conversa a um registro do Odoo e envie mensagens ao chatter
          </DialogDescription>
        </DialogHeader>

        {/* Conversation info */}
        <div className="flex items-center gap-2 text-sm text-muted-foreground rounded-lg bg-muted/40 px-3 py-2">
          <Phone className="size-3.5" />
          <span className="font-medium">{phone}</span>
          {conversationPushName && (
            <>
              <span className="text-muted-foreground/50">|</span>
              <User className="size-3.5" />
              <span>{conversationPushName}</span>
            </>
          )}
        </div>

        {/* Already linked records */}
        {linkedRecords.length > 0 && (
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Registros Vinculados
            </Label>
            <div className="flex flex-col gap-1.5">
              {linkedRecords.map(lr => {
                const cfg = CHATTER_MODELS[lr.modelKey]
                const Icon = cfg.icon
                const isSelected = selectedForChatter?.recordId === lr.recordId && selectedForChatter?.model === lr.model
                return (
                  <div key={`${lr.model}-${lr.recordId}`} className={cn(
                    "flex items-center gap-2 rounded-lg border px-3 py-2 cursor-pointer transition-colors",
                    isSelected ? "border-primary bg-primary/5" : "border-border hover:bg-muted/50"
                  )} onClick={() => setSelectedForChatter(isSelected ? null : lr)}>
                    <Icon className="size-4 text-muted-foreground shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{getRecordName(lr.record)}</div>
                      <div className="text-xs text-muted-foreground">{cfg.label} #{lr.recordId}</div>
                    </div>
                    <CheckCircle2 className="size-4 text-emerald-500 shrink-0" />
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Post to chatter */}
        {selectedForChatter && (
          <div className="space-y-2 rounded-lg border border-primary/20 bg-primary/5 p-3">
            <Label className="text-xs font-semibold text-primary">Enviar ao Chatter de {getRecordName(selectedForChatter.record)}</Label>
            <Textarea
              value={chatterMessage}
              onChange={e => setChatterMessage(e.target.value)}
              placeholder="Digite uma mensagem para o chatter do Odoo..."
              rows={3}
              className="text-sm"
            />
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                className="h-8 gap-1.5 text-xs bg-primary hover:bg-primary/90 text-primary-foreground"
                onClick={handlePostToChatter}
                disabled={!chatterMessage.trim() || postingMsg}
              >
                {postingMsg ? <Loader2 className="size-3.5 animate-spin" /> : <MessageSquare className="size-3.5" />}
                Enviar ao Chatter
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-8 gap-1.5 text-xs"
                onClick={autoFillConversationMsg}
                disabled={messages.length === 0}
              >
                <MessageSquare className="size-3.5" />
                Incluir Historico da Conversa
              </Button>
            </div>
          </div>
        )}

        {/* Tab selector for models */}
        <div className="space-y-2">
          <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Buscar Registro para Vincular
          </Label>
          <div className="flex gap-1.5">
            {(Object.entries(CHATTER_MODELS) as [ChatterModelKey, typeof CHATTER_MODELS[ChatterModelKey]][]).map(([key, cfg]) => {
              const Icon = cfg.icon
              const isActive = activeTab === key
              return (
                <Button
                  key={key}
                  variant={isActive ? "default" : "outline"}
                  size="sm"
                  className={cn("h-8 gap-1.5 text-xs flex-1", !isActive && "hover:bg-muted")}
                  onClick={() => setActiveTab(key)}
                >
                  <Icon className="size-3.5" />
                  {cfg.label}
                </Button>
              )
            })}
          </div>
        </div>

        {/* Search bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={e => handleSearchChange(e.target.value)}
            placeholder={CHATTER_MODELS[activeTab].placeholder}
            className="h-9 pl-9 pr-8 text-sm"
          />
          {searchQuery && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-1 top-1 size-7"
              onClick={() => { setSearchQuery(''); setSearchResults([]); setSearchSearched(false) }}
            >
              <X className="size-3" />
            </Button>
          )}
        </div>

        {/* Search results */}
        <div className="flex-1 min-h-0 max-h-48 overflow-y-auto rounded-lg border">
          {searchLoading && (
            <div className="flex items-center justify-center py-8 gap-2">
              <Loader2 className="size-5 animate-spin text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Buscando...</span>
            </div>
          )}
          {!searchLoading && searchSearched && searchResults.length === 0 && (
            <div className="flex flex-col items-center gap-2 py-8 text-center">
              <Search className="size-6 text-muted-foreground/50" />
              <p className="text-sm text-muted-foreground">Nenhum resultado encontrado</p>
            </div>
          )}
          {!searchLoading && searchResults.map(record => {
            const linked = isRecordLinked(CHATTER_MODELS[activeTab].model, record.id)
            const Icon = CHATTER_MODELS[activeTab].icon
            return (
              <div
                key={record.id}
                className={cn(
                  "flex items-center gap-3 px-3 py-2 border-b last:border-b-0 transition-colors",
                  linked ? "bg-emerald-50/50 dark:bg-emerald-950/20" : "hover:bg-muted/50 cursor-pointer"
                )}
                onClick={() => {
                  if (!linked) handleLink(CHATTER_MODELS[activeTab].model, activeTab, record.id, record)
                }}
              >
                <div className="size-8 rounded-lg bg-muted/60 flex items-center justify-center shrink-0">
                  <Icon className="size-4 text-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{getRecordName(record)}</div>
                  <div className="text-xs text-muted-foreground truncate">{getRecordSubInfo(record, activeTab)}</div>
                </div>
                {linkingId === record.id ? (
                  <Loader2 className="size-4 animate-spin text-primary shrink-0" />
                ) : linked ? (
                  <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 text-[10px] shrink-0">
                    <CheckCircle2 className="size-3" /> Vinculado
                  </Badge>
                ) : (
                  <Button variant="outline" size="sm" className="h-7 text-xs gap-1 shrink-0">
                    <Link2 className="size-3" />
                    Vincular
                  </Button>
                )}
              </div>
            )
          })}
          {!searchLoading && !searchSearched && (
            <div className="flex flex-col items-center gap-2 py-8 text-center">
              <Search className="size-6 text-muted-foreground/30" />
              <p className="text-sm text-muted-foreground">Digite para buscar registros</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Fechar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ========== Main ChatView ==========

export function ChatView({
  conversation,
  messages,
  onSendMessage,
  onMarkRead,
  odooConnected = false,
  odooSyncInfo = null,
  onCreateLead,
  onCreateContact,
  onLinkConversation,
  onSearchContacts,
  onSearchLeads,
  onSearchSales,
  onSearchTasks,
  onLogMessage,
  onToggleOdooPanel,
  odooPanelOpen = false,
}: ChatViewProps) {
  const [inputText, setInputText] = useState('')
  const [isSending, setIsSending] = useState(false)
  const [showScrollButton, setShowScrollButton] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Create lead dialog state
  const [createLeadOpen, setCreateLeadOpen] = useState(false)
  const [leadName, setLeadName] = useState('')
  const [includeConversation, setIncludeConversation] = useState(true)
  const [creating, setCreating] = useState(false)

  // Create contact dialog state
  const [createContactOpen, setCreateContactOpen] = useState(false)
  const [contactName, setContactName] = useState('')
  const [creatingContact, setCreatingContact] = useState(false)

  // Chatter link dialog state
  const [chatterDialogOpen, setChatterDialogOpen] = useState(false)

  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior })
  }, [])

  // Auto-scroll on new messages
  useEffect(() => {
    scrollToBottom()
  }, [messages.length, scrollToBottom])

  // Mark as read when selecting a conversation
  useEffect(() => {
    if (conversation) {
      onMarkRead(conversation.jid)
    }
  }, [conversation?.jid, onMarkRead])

  // Track scroll position for "scroll to bottom" button
  useEffect(() => {
    const viewport = scrollAreaRef.current?.querySelector('[data-slot="scroll-area-viewport"]')
    if (!viewport) return

    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = viewport as HTMLElement
      const distanceFromBottom = scrollHeight - scrollTop - clientHeight
      setShowScrollButton(distanceFromBottom > 150)
    }

    viewport.addEventListener('scroll', handleScroll)
    return () => viewport.removeEventListener('scroll', handleScroll)
  }, [])

  // Pre-fill lead/contact name when conversation changes
  useEffect(() => {
    if (conversation) {
      const name = conversation.pushName || conversation.phone || conversation.jid.split('@')[0]
      setLeadName(`[WhatsApp] ${name}`)
      setContactName(name)
    }
  }, [conversation])

  const handleSend = async () => {
    const text = inputText.trim()
    if (!text || !conversation || isSending) return

    setIsSending(true)
    try {
      const success = await onSendMessage(conversation.jid, text)
      if (success) {
        setInputText('')
      }
    } finally {
      setIsSending(false)
      inputRef.current?.focus()
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleCreateLead = async () => {
    if (!conversation || !onCreateLead) return
    setCreating(true)
    try {
      const success = await onCreateLead(conversation.jid, {
        name: leadName,
        phone: conversation.phone || conversation.jid.split('@')[0],
        pushName: conversation.pushName,
        messages: includeConversation ? messages : [],
      })
      if (success) {
        setCreateLeadOpen(false)
      }
    } finally {
      setCreating(false)
    }
  }

  const handleCreateContact = async () => {
    if (!conversation || !onCreateContact) return
    setCreatingContact(true)
    try {
      const success = await onCreateContact(conversation.jid, {
        name: contactName,
        phone: conversation.phone || conversation.jid.split('@')[0],
        pushName: conversation.pushName,
      })
      if (success) {
        setCreateContactOpen(false)
      }
    } finally {
      setCreatingContact(false)
    }
  }

  const displayName =
    conversation?.name || conversation?.pushName || conversation?.phone || conversation?.jid?.split('@')[0] || ''

  // Empty state - no conversation selected
  if (!conversation) {
    return (
      <div className="flex flex-col items-center justify-center h-full bg-muted/20">
        <div className="flex flex-col items-center gap-3 text-center px-4">
          <div className="size-20 rounded-full bg-muted/60 flex items-center justify-center">
            <MessageSquare className="size-8 text-muted-foreground/50" />
          </div>
          <h3 className="text-lg font-semibold text-muted-foreground">Nenhuma conversa selecionada</h3>
          <p className="text-sm text-muted-foreground/70 max-w-[280px]">
            Selecione uma conversa da lista para comecar a ver mensagens
          </p>
        </div>
      </div>
    )
  }

  const hasExistingPartner = odooSyncInfo?.partnerId != null
  const hasExistingLead = odooSyncInfo?.leadId != null

  return (
    <div className="flex flex-col h-full">
      {/* Chat Header */}
      <div className="shrink-0 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex items-center gap-3 px-4 py-3">
          <Avatar className="size-10">
            {conversation.avatarUrl && (
              <AvatarImage src={conversation.avatarUrl} alt={displayName} />
            )}
            <AvatarFallback className="bg-primary/10 text-primary text-sm">
              {displayName
                .split(' ')
                .map((w) => w[0])
                .filter(Boolean)
                .slice(0, 2)
                .join('')
                .toUpperCase() || <User className="size-4" />}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-sm truncate">{displayName}</h3>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              {conversation.phone ? (
                <>
                  <Phone className="size-3" />
                  <span>{conversation.phone}</span>
                </>
              ) : (
                <span>{conversation.jid.split('@')[0]}</span>
              )}
              {/* Odoo sync badges */}
              {hasExistingPartner && (
                <Badge variant="outline" className="text-[9px] px-1 py-0 h-4 ml-1 bg-emerald-50 text-emerald-700 border-emerald-200">
                  Contato #{odooSyncInfo!.partnerId}
                </Badge>
              )}
              {hasExistingLead && (
                <Badge variant="outline" className="text-[9px] px-1 py-0 h-4 ml-1 bg-amber-50 text-amber-700 border-amber-200">
                  Lead #{odooSyncInfo!.leadId}
                </Badge>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          {odooConnected && (
            <div className="flex items-center gap-1.5">
              {/* Criar Contato */}
              <Button
                variant={hasExistingPartner ? "ghost" : "outline"}
                size="sm"
                className={cn(
                  "h-8 gap-1.5 text-xs",
                  !hasExistingPartner && "border-emerald-300 text-emerald-700 hover:bg-emerald-50 hover:text-emerald-800 bg-emerald-50/50"
                )}
                onClick={() => setCreateContactOpen(true)}
                disabled={hasExistingPartner}
                title={hasExistingPartner ? 'Contato ja existe no Odoo' : 'Criar contato no Odoo'}
              >
                {hasExistingPartner ? (
                  <CheckCircle2 className="size-3.5 text-emerald-500" />
                ) : (
                  <UserPlus className="size-3.5" />
                )}
                <span className="hidden sm:inline">{hasExistingPartner ? 'Contato OK' : 'Contato'}</span>
              </Button>

              {/* Criar Lead */}
              <Button
                variant={hasExistingLead ? "ghost" : "outline"}
                size="sm"
                className={cn(
                  "h-8 gap-1.5 text-xs",
                  !hasExistingLead && "border-amber-300 text-amber-700 hover:bg-amber-50 hover:text-amber-800 bg-amber-50/50"
                )}
                onClick={() => setCreateLeadOpen(true)}
                disabled={hasExistingLead}
                title={hasExistingLead ? 'Lead ja existe no Odoo' : 'Criar lead no Odoo com historico da conversa'}
              >
                {hasExistingLead ? (
                  <CheckCircle2 className="size-3.5 text-emerald-500" />
                ) : (
                  <Target className="size-3.5" />
                )}
                <span className="hidden sm:inline">{hasExistingLead ? 'Lead OK' : 'Lead'}</span>
              </Button>

              {/* Vincular ao Chatter — Opens dialog */}
              <Button
                variant="outline"
                size="sm"
                className="h-8 gap-1.5 text-xs font-medium border-primary/40 text-primary hover:bg-primary/10 hover:text-primary"
                onClick={() => setChatterDialogOpen(true)}
                title="Vincular conversa ao chatter do Odoo"
              >
                <Link2 className="size-3.5" />
                <span className="hidden sm:inline">Vincular ao Chatter</span>
              </Button>
            </div>
          )}

          {!odooConnected && (
            <Badge variant="outline" className="text-[10px] text-muted-foreground">
              Odoo offline
            </Badge>
          )}
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 relative overflow-hidden">
        <ScrollArea ref={scrollAreaRef} className="h-full">
          <div className="px-4 py-3 space-y-1">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16">
                <div className="size-14 rounded-full bg-muted/50 flex items-center justify-center mb-3">
                  <MessageSquare className="size-6 text-muted-foreground/40" />
                </div>
                <p className="text-sm text-muted-foreground">Sem mensagens ainda</p>
                <p className="text-xs text-muted-foreground/60 mt-1">
                  Envie uma mensagem para iniciar a conversa
                </p>
              </div>
            ) : (
              messages.map((message, index) => {
                const prevMessage = index > 0 ? messages[index - 1] : undefined
                const showDateDivider = shouldShowDateDivider(message, prevMessage)
                const isConsecutive =
                  prevMessage &&
                  prevMessage.fromMe === message.fromMe &&
                  new Date(message.timestamp).getTime() - new Date(prevMessage.timestamp).getTime() < 60000

                return (
                  <div key={message.id}>
                    {/* Date Divider */}
                    {showDateDivider && (
                      <div className="flex items-center justify-center py-3">
                        <Badge
                          variant="secondary"
                          className="text-[10px] px-3 py-0.5 font-normal bg-muted/80 text-muted-foreground"
                        >
                          {formatMessageDate(message.timestamp)}
                        </Badge>
                      </div>
                    )}

                    {/* Message Bubble */}
                    <div
                      className={cn(
                        'flex',
                        message.fromMe ? 'justify-end' : 'justify-start',
                        isConsecutive ? 'mt-0.5' : 'mt-2'
                      )}
                    >
                      <div
                        className={cn(
                          'max-w-[75%] sm:max-w-[65%] rounded-2xl px-3 py-1.5 shadow-sm',
                          message.fromMe
                            ? 'bg-emerald-600 text-white rounded-br-md'
                            : 'bg-muted rounded-bl-md',
                          isConsecutive &&
                            (message.fromMe ? 'rounded-br-md' : 'rounded-bl-md')
                        )}
                      >
                        {/* Media indicator */}
                        {message.mediaType && message.mediaType !== '' && (
                          <div
                            className={cn(
                              'flex items-center gap-2 mb-1 px-2 py-1.5 rounded-lg text-xs',
                              message.fromMe
                                ? 'bg-emerald-500/50'
                                : 'bg-background/50'
                            )}
                          >
                            {getMediaIcon(message.mediaType)}
                            <span className="font-medium">{getMediaLabel(message.mediaType)}</span>
                          </div>
                        )}

                        {/* Text content */}
                        {message.textContent && (
                          <p className="text-[13px] leading-relaxed whitespace-pre-wrap break-words">
                            {message.textContent}
                          </p>
                        )}

                        {/* Only media, no text */}
                        {message.mediaType && !message.textContent && (
                          <p className="text-[13px] leading-relaxed italic opacity-70">
                            {getMediaLabel(message.mediaType)}
                          </p>
                        )}

                        {/* Timestamp & Status */}
                        <div
                          className={cn(
                            'flex items-center gap-1 mt-0.5',
                            message.fromMe ? 'justify-end' : 'justify-start'
                          )}
                        >
                          <span
                            className={cn(
                              'text-[10px]',
                              message.fromMe
                                ? 'text-white/60'
                                : 'text-muted-foreground'
                            )}
                          >
                            {formatMessageTime(message.timestamp)}
                          </span>
                          {getMessageStatusIcon(message.status, message.fromMe)}
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Scroll to bottom button */}
        {showScrollButton && (
          <Button
            variant="secondary"
            size="icon"
            className="absolute bottom-4 right-4 size-9 rounded-full shadow-lg opacity-80 hover:opacity-100 transition-opacity"
            onClick={() => scrollToBottom()}
          >
            <ArrowDown className="size-4" />
          </Button>
        )}
      </div>

      {/* Message Input */}
      <Separator />
      <div className="shrink-0 px-4 py-3 bg-background">
        <div className="flex items-center gap-2">
          <Input
            ref={inputRef}
            placeholder="Digite uma mensagem..."
            className="flex-1 h-10 text-sm"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isSending}
          />
          <Button
            size="icon"
            className="size-10 shrink-0 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white"
            onClick={handleSend}
            disabled={!inputText.trim() || isSending}
          >
            {isSending ? (
              <span className="size-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Send className="size-4" />
            )}
          </Button>
        </div>
      </div>

      {/* ========== Create Lead Dialog ========== */}
      <Dialog open={createLeadOpen} onOpenChange={setCreateLeadOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Target className="size-5 text-amber-500" />
              Criar Lead no Odoo
            </DialogTitle>
            <DialogDescription>
              Crie um lead no CRM do Odoo a partir desta conversa do WhatsApp
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label htmlFor="lead-name">Nome do Lead</Label>
              <Input
                id="lead-name"
                value={leadName}
                onChange={(e) => setLeadName(e.target.value)}
                placeholder="Nome do lead"
              />
            </div>

            <div className="flex items-center gap-3 text-sm">
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <Phone className="size-3.5" />
                <span>{conversation.phone || conversation.jid.split('@')[0]}</span>
              </div>
              {conversation.pushName && (
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <User className="size-3.5" />
                  <span>{conversation.pushName}</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-3 rounded-lg border p-3">
              <input
                type="checkbox"
                id="include-conversation"
                checked={includeConversation}
                onChange={(e) => setIncludeConversation(e.target.checked)}
                className="size-4 rounded border-gray-300"
              />
              <div className="flex-1">
                <Label htmlFor="include-conversation" className="text-sm font-medium cursor-pointer">
                  Incluir historico da conversa na descricao
                </Label>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {includeConversation
                    ? `${messages.length} mensagens serao incluidas na descricao do lead`
                    : 'O lead sera criado sem o historico da conversa'
                  }
                </p>
              </div>
            </div>

            {/* Preview of conversation that will be included */}
            {includeConversation && messages.length > 0 && (
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">Previa da conversa</Label>
                <div className="max-h-40 overflow-y-auto rounded-lg border bg-muted/30 p-3 text-xs font-mono whitespace-pre-wrap">
                  {formatConversationForDescription(conversation.pushName, conversation.phone, messages.slice(-20))}
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateLeadOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleCreateLead} disabled={!leadName.trim() || creating} className="bg-amber-600 hover:bg-amber-700 text-white">
              {creating ? <Loader2 className="size-4 animate-spin" /> : <Target className="size-4" />}
              Criar Lead
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ========== Create Contact Dialog ========== */}
      <Dialog open={createContactOpen} onOpenChange={setCreateContactOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserPlus className="size-5 text-emerald-500" />
              Criar Contato no Odoo
            </DialogTitle>
            <DialogDescription>
              Crie um contato no Odoo a partir desta conversa do WhatsApp
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label htmlFor="contact-name">Nome do Contato</Label>
              <Input
                id="contact-name"
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
                placeholder="Nome do contato"
              />
            </div>
            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <Phone className="size-3.5" />
              <span>{conversation.phone || conversation.jid.split('@')[0]}</span>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateContactOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleCreateContact} disabled={!contactName.trim() || creatingContact} className="bg-emerald-600 hover:bg-emerald-700 text-white">
              {creatingContact ? <Loader2 className="size-4 animate-spin" /> : <UserPlus className="size-4" />}
              Criar Contato
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ========== Chatter Link Dialog ========== */}
      {onLinkConversation && (
        <ChatterLinkDialog
          open={chatterDialogOpen}
          onOpenChange={setChatterDialogOpen}
          conversationJid={conversation.jid}
          conversationPhone={conversation.phone}
          conversationPushName={conversation.pushName}
          messages={messages}
          odooConnected={!!odooConnected}
          onLinkConversation={onLinkConversation}
          onSearchContacts={onSearchContacts}
          onSearchLeads={onSearchLeads}
          onSearchSales={onSearchSales}
          onSearchTasks={onSearchTasks}
          onLogMessage={onLogMessage}
          existingPartnerId={odooSyncInfo?.partnerId ?? null}
          existingLeadId={odooSyncInfo?.leadId ?? null}
        />
      )}
    </div>
  )
}
