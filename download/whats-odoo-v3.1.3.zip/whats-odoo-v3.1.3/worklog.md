---
Task ID: 1
Agent: main
Task: Fix OOM/EADDRINUSE by merging 3 processes into 1 single-process server

Work Log:
- Analyzed entire codebase: server.js, whatsapp-service/index.ts, odoo-service/index.ts, package.json, render.yaml
- Root cause of OOM: 3 Node.js processes (server + tsx whatsapp + tsx odoo) = ~450MB+ on 512MB Render free tier
- Root cause of EADDRINUSE: Render start command AND npm start both launched mini-services, causing port 3002 collision
- Rewrote server.js as single-process server merging WhatsApp Baileys + Odoo XML-RPC + Next.js Socket.io
- Updated package.json: simplified start command, removed tsx from runtime, added NODE_OPTIONS --max-old-space-size=384
- Updated render.yaml: removed WHATSAPP_SERVICE_URL/ODOO_SERVICE_URL (no longer needed), kept startCommand as npm run start
- Updated start.sh: simplified for backup use only
- Improved WhatsApp reconnection: exponential backoff (2s→4s→8s→16s→30s), infinite reconnects (no MAX limit)
- Increased keepAliveIntervalMs from 25s to 30s for better stability
- Reduced memory limits: MAX_DEDUP_IDS from 2000→1000, MAX_MESSAGES_PER_CONVERSATION from 200→100
- Added periodic memory monitoring (every 5 min)
- Verified all v3.0 features are present: Create Lead, Create Contact, Copy conversation to description, Vincular ao Chatter button, message deduplication

Stage Summary:
- server.js: Complete rewrite (~750 lines, single process)
- package.json: version 3.1.1, start command: mkdir + prisma db push + node server.js
- render.yaml: Simplified, no internal service URLs
- start.sh: Simplified backup script
- Memory savings: ~3 processes → 1 process = ~200-250MB estimated (fits in 512MB)
- File: /home/z/my-project/download/whats-odoo-v3.1.1.zip (87KB)
